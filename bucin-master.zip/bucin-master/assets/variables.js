export default {
  nicknames: ["Diana", "Naa", "Sayang", "Ayang"],
  greetings: {
    evening: "Good Evening",
    afternoon: "Good Afternoon",
    day: "Good Day",
    morning: "Good Morning",
    night: "Good Night"
  }
};
