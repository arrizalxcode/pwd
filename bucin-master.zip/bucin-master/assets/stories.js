export default [
  "Hi!",
  "Klik next ya!",
  "Udah itu aja",
  "Aku sayang kamu!"
];
