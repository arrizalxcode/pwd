// prettier-ignore
export default [
    { author: "avrill.v", quotes: "Whatever happens, keep breathing" },
    { author: "antjedtta_", quotes: "Pam pam pararam ceklek jedar\nPararam ram parararam ram" },
    { author: "standinshd", quotes: "Hey! I wuv chuuuu! UwU" },
    { author: "standinshd", quotes: "I love you." },
    { author: "standinshd", quotes: "I may not with you everyday, but I love you everyday." },
    { author: "standinshd", quotes: "I love you." },
    { author: "standinshd", quotes: "I'm sorry for loving you." },
];
